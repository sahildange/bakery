/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cake_shop;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
//import java.util.Date;
import java.sql.Date;

/**
 *
 * @author Megha_Sawant
 */
public class user {

    int id;
    String e_name;
    String flavor, weight, desc;
    int price;
    int o_id;
    String c_name, c_no,o_date;
    String p_name,category;

    //Employee Details 
    public user(int id, String Name) {
        this.id = id;
        this.e_name = Name;
    }

    public int getid() {
        return id;
    }
    public String get_name() {
        return e_name;
    }

    //Product Details 
    public user(int Id, String Product_Name, String Flavor, String Weight, int Price, String Description) {
        this.id = Id;
        this.p_name = Product_Name;
        this.flavor = Flavor;
        this.weight = Weight;
        this.price = Price;
        this.desc = Description;
    }

    public int getp_id() {
        return id;
    }
    public String getp_name() {
        return p_name;
    }
    public String getp_flavor() {
        return flavor;
    }
    public String getp_weight() {
        return weight;
    }
    public int getp_price() {
        return price;
    }
    public String getp_desc() {
        return desc;
    }

    //Order Details _Customer
    public user(int order_id, String Customer_Name, String Customer_Number, String Order_Date) {
        this.o_id = order_id;
        this.c_name = Customer_Name;
        this.c_no = Customer_Number;
        this.o_date = Order_Date;
    }

    public int geto_id() {
        return o_id;
    }
    public String getc_name() {
        return c_name;
    }
    public String getc_no() {
        return c_no;
    }
    public String geto_date() {
        return o_date;
    }
    
    //Order Details 
    public user(String Category,String Product_Name,String Flavor,int Price, String Product_Description) {
        this.p_name = Product_Name;
        this.category = Category;
        this.flavor = Flavor;
        this.price = Price;
        this.desc = Product_Description;
    }
    public String get_category() {
        return category;
    }
    
    public user(String Customer_Name,String Order_Date, String Product_Name, String Category, String Flavor)
    {
        this.c_name = Customer_Name;
        this.o_date = Order_Date;
        this.p_name = Product_Name;
        this.category = Category;
        this.flavor = Flavor;
    }
}
