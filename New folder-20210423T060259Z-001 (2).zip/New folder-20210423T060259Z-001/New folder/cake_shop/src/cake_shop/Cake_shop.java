/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cake_shop;

import cake.*;

/**
 *
 * @author Megha_Sawant
 */
public class Cake_shop {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        login1 m1 = new login1();
        m1.setTitle("Login Window");
        m1.setVisible(true);
        
        
        login m = new login();
        m.setTitle("Login Window");
        m.setVisible(true);
    }

}
