/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

/**
 *
 * @author Megha_Sawant
 */

public class database implements Provider{
    public static Connection connection;

    
    // getConnection() to get mysql Connection
    public static Connection getConnection(){
          try{
        	  if(connection == null || connection.isClosed()){
                      Class.forName(DRIVER_NAME);
        	      connection = DriverManager.getConnection(HOST_NAME+DATABASE_NAME,USER_NAME,PASSWORD);
        	  }
               System.out.println("Connection is success...");
            }catch(Exception ex){
                System.out.println("Exception DB.java Connection Time : "+ex.getMessage());
            }
        return connection;
    }
    
    /**
     * @param Connection con
     * @return boolean
     */
    public static boolean closeConnection(Connection con){
    	boolean isValid = false;
    	try{
    		con.close();
//    		System.out.println("Connection is close successfully...");
    	}catch(Exception ex){
    		System.out.println("Exception  closeConnection() : DB.java : "+ex.getMessage());
    	}
    	return isValid;
    }
}

