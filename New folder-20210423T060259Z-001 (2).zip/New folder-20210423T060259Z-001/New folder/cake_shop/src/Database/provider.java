/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Database;

/**
 *
 * @author Megha_Sawant
 */
interface Provider {
    // Database constatnt variable names
   public static final String DRIVER_NAME ="com.mysql.cj.jdbc.Driver"; // Drivers Name
   public static final String DATABASE_NAME ="cake_shop"; // database name
   public static final String HOST_NAME ="jdbc:mysql://localhost:3306/"; // Host name
   public static final String USER_NAME ="root"; //Database user name
   public static final String PASSWORD ="Aa@1mysql"; //Database password name
 }
