# HeidiSQL Dump 
#
# --------------------------------------------------------
# Host:                 127.0.0.1
# Database:             cake_shop
# Server version:       6.0.11-alpha-community
# Server OS:            Win32
# Target-Compatibility: Same as source server (MySQL 6.0.11-alpha-community)
# max_allowed_packet:   1048576
# HeidiSQL version:     3.2 Revision: 1129
# --------------------------------------------------------

/*!40100 SET CHARACTER SET latin1*/;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0*/;


#
# Database structure for database 'cake_shop'
#

CREATE DATABASE `cake_shop` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `cake_shop`;


#
# Table structure for table 'employee_details'
#

CREATE TABLE `employee_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Date_of_Joining` date NOT NULL,
  `Contact_No` double NOT NULL,
  `Salary` varchar(50) NOT NULL,
  `DOB` date NOT NULL,
  `Age` int(10) unsigned NOT NULL,
  `Address` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 /*!40100 DEFAULT CHARSET=latin1*/;



#
# Dumping data for table 'employee_details'
#

LOCK TABLES `employee_details` WRITE;
/*!40000 ALTER TABLE `employee_details` DISABLE KEYS*/;
INSERT INTO `employee_details` (`id`, `Name`, `Date_of_Joining`, `Contact_No`, `Salary`, `DOB`, `Age`, `Address`) VALUES
	('1','ramesh','2018-04-10','9842154215','10000','2018-04-13','23','pune');
/*!40000 ALTER TABLE `employee_details` ENABLE KEYS*/;
UNLOCK TABLES;


#
# Table structure for table 'order_details'
#

CREATE TABLE `order_details` (
  `order_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `Customer_Name` varchar(50) NOT NULL,
  `Customer_Number` double NOT NULL,
  `Product_Name` varchar(50) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Flavor` varchar(50) NOT NULL,
  `Price` int(11) NOT NULL,
  `Product_Description` varchar(250) NOT NULL,
  `Order_Date` varchar(20) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 /*!40100 DEFAULT CHARSET=latin1*/;



#
# Dumping data for table 'order_details'
#

LOCK TABLES `order_details` WRITE;
/*!40000 ALTER TABLE `order_details` DISABLE KEYS*/;
INSERT INTO `order_details` (`order_id`, `Customer_Name`, `Customer_Number`, `Product_Name`, `Category`, `Flavor`, `Price`, `Product_Description`, `Order_Date`) VALUES
	('1','sam','9842154215','Cake','Black Forest Round Cake','Black Forest',300,'It consist a fresh mushy red or chocolate sponge at the \nbase smothered with majestic layers of fresh whipped cream and cherries. ','2018-04-13'),
	('2','sam','9842154215','Chocolates','Melting Sensation','Coffee and orange dark chocolate',150,'Center filled Chocolates consisting of caramel coconut in milk chocolates and coffee and orange dark chocolate.	','2018-04-13'),
	('3','rushi','7715421546','Cookies','Kesar Cookies','Kesar',60,'\n\nIngredients:\n\n    Wheat Flour\n    Hydrogenated Vegetable Fat Contains Trans Fat\n    Sugar\n    Milk Solids\n    Water\n    Kesar Syrup\n    Iodised Salt\n    Kesar\n     Antioxidant\n\n','2018-03-13'),
	('4','rushi','7715421546','Chocolates','Dry Fruit Rocks','dry fruits, Cashew nut and Almond',300,'Combination of Milk and Dark Chocolate with dry fruits like Pista Flakes, Cashew nut and Almond','2018-04-13');
/*!40000 ALTER TABLE `order_details` ENABLE KEYS*/;
UNLOCK TABLES;


#
# Table structure for table 'product_details'
#

CREATE TABLE `product_details` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `Product_Category` varchar(20) NOT NULL,
  `Product_Name` varchar(100) NOT NULL,
  `Flavor` varchar(100) NOT NULL,
  `Weight` varchar(20) NOT NULL,
  `Price` int(20) DEFAULT NULL,
  `Description` varchar(250) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 /*!40100 DEFAULT CHARSET=latin1*/;



#
# Dumping data for table 'product_details'
#

LOCK TABLES `product_details` WRITE;
/*!40000 ALTER TABLE `product_details` DISABLE KEYS*/;
INSERT INTO `product_details` (`ID`, `Product_Category`, `Product_Name`, `Flavor`, `Weight`, `Price`, `Description`) VALUES
	('1','Cake','Mango Kesar Cake','Mango Fresh Cream','500gms',300,' It is decorated with kesar glaze, chocolate\n garnish and topped with fresh mango\n flavor cream to offer the taste of real\n mangoes in every bite.'),
	('2','Cake','Black Forest Round Cake','Black Forest','500gms',300,'It consist a fresh mushy red or chocolate sponge at the \nbase smothered with majestic layers of fresh whipped cream and cherries. '),
	('3','Cake','Pineapple Cake','Pineapple','500gms',300,'Pineapple Cake '),
	('4','Chocolates','Dry Fruit Rocks','dry fruits, Cashew nut and Almond','200gms',300,'Combination of Milk and Dark Chocolate with dry fruits like Pista Flakes, Cashew nut and Almond'),
	('5','Pastry','Choco Lava Veg Cup','Chocolate','50gms',55,'Delicious Chocolate Cupcake made more interesting with molten chocolate at the centre. Fun filled cup cake pastry is an all time favorite for all. '),
	('6','Pastry','Brownie Square Veg Pastry','Chocolate Borwnie','50gms',40,'Perfect gift for your loved ones! Dark chocolate walnut brownie sponge is layered and coated with rich Dutch ganache for special love.'),
	('7','Chocolates','Chocolate Rocks','Dark Chocolate with Rice Crispies and Noughat','50gms',130,'Enjoy Real Taste Combination of Milk and Dark Chocolate with Rice Crispies and Noughat ..'),
	('8','Cookies','Choco Chips Cookies','Choco Chips','200gms',50,'\n\nIngredients:\n\n    Wheat Flour\n    Sugar\n    Hydrogenated Vegetable Fat Contains Trans Fat\n    Water\n    Milk Solids\n    Choco Chips\n    Cocoa Solids\n    Leavening Agent\n    Iodised Salt. \n\n'),
	('9','Cookies','Kesar Cookies','Kesar','200gms',60,'\n\nIngredients:\n\n    Wheat Flour\n    Hydrogenated Vegetable Fat Contains Trans Fat\n    Sugar\n    Milk Solids\n    Water\n    Kesar Syrup\n    Iodised Salt\n    Kesar\n     Antioxidant\n\n'),
	('10','Savouries','Mava Bar Cake Veg','Veg','225gms',80,'\n\nIngredients:\n\n    Wheat Flour\n    Sugar\n    Water\n    Edible Vegetable Oil\n    Sweetened Condensed Milk\n    Milk Solids\n    Humectant\n    Iodised Salt\n    Leavening Agents\n\n'),
	('11','Cake','Rainbow Veg Premium Cake','Premium','500gms',350,'Rainbow Veg Premium Cake '),
	('12','Pastry','Fresh Fruit Prem Pastry','Fruit','50gms',55,'Fruits combined with cream to refreshen you up! Silky vanilla sponge layered with real fresh cream and chopped fresh fruits. Embellished with fruit cream and fresh fruits. Loveable treat for everyone! '),
	('13','Savouries','Donuts Veg','Chocolate','150gms',27,'\n\nIngredients:\n\n    Wheat Flour\n    Water\n    Sugar\n    Hydrogenated Vegetable Fat Contain Trans Fat\n    Milk Soilds\n    Yeast\n    Iodised Salt\n    Emulsifiers\n\n'),
	('14','Chocolates','Melting Sensation','Coffee and orange dark chocolate','200gms',150,'Center filled Chocolates consisting of caramel coconut in milk chocolates and coffee and orange dark chocolate.	'),
	('15','Savouries','Pan Pizza Chicken','Non-veg','None',38,'Ingredients:\n\n    Wheat Flour\n    Minced Chicken\n    Tomatoes\n    Onions\n    Capsicum\n    Spring Onions\n    Mixed Spices And Condiments\n    Cheese\n    Iodised Salt\n    Sugar\n    E'),
	('16','Cookies','Shrewsbury Cookies','Shrewsbury','200gms',50,'\n\nIngredients:\n\n    Wheat Flour\n    Sugar\n    Butter\n    Hydrogenated Vegetable Fat contains Trans Fat\n    Water\n    Leavening Agent\n\n'),
	('17','Cake','Red Velvet Cake','Premium','500gms',450,'Smooth as velvet! It contains rich red velvety sponge & layers of pure, thick cheese cream frosting. Real slice of heaven! '),
	('18','Pastry','Cashew Finger Pastries','Cashew Nuts','None',30,'Cashew Finger Pastries '),
	('19','Pastry','Butter Scotch Veg Pastry','Butter Scotch','None',30,'Butter Scotch Veg Pastry'),
	('20','Savouries','Whole Wheat Pizza Bread','None','200gms',30,'\n\nIngredients:\n\n    WHEAT FLOUR\n    WATER\n    HYDROGENATED VEGETABLE FAT CONTAINS TRANS FAT\n    SUGAR\n    YEAST\n    IODISED SALT\n    EMULSIFIERS\n\n');
/*!40000 ALTER TABLE `product_details` ENABLE KEYS*/;
UNLOCK TABLES;


#
# Table structure for table 'users'
#

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `user_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40100 DEFAULT CHARSET=latin1*/;



#
# Dumping data for table 'users'
#

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS*/;
INSERT INTO `users` (`id`, `username`, `password`, `user_type`) VALUES
	(1,'admin','admin','admin'),
	(2,'employee','employee','employee');
/*!40000 ALTER TABLE `users` ENABLE KEYS*/;
UNLOCK TABLES;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS*/;
